import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "Part3"))

from studio import Studio

app = Studio()
app.mainloop()
