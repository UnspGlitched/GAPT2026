#!/usr/bin/env python3
"""
Script-to-Scene Studio
Unified GUI: generate script (Part 1) -> render audio (Part 2) -> render video (Part 3).
Run from anywhere: python Part3/studio.py   OR   python launch.py (from Group APT root)
"""

import contextlib
import io
import json
import os
import subprocess
import sys
import tempfile
import threading
import tkinter as tk
from tkinter import filedialog, ttk, scrolledtext, messagebox
from pathlib import Path

# ── import Part 1's generator ──────────────────────────────────────────────────
PART1_PATH = Path(__file__).parent.parent / "Part1" / "Script Generator"
sys.path.insert(0, str(PART1_PATH))

PART1_AVAILABLE = False
PART1_ERROR = ""
try:
    from story_script_generator import StorySceneGenerator
    PART1_AVAILABLE = True
except ImportError as _e:
    PART1_ERROR = str(_e)

# ── import Part 2's audio renderer ────────────────────────────────────────────
PART2_PATH = Path(__file__).parent.parent / "Part2"
sys.path.insert(0, str(PART2_PATH))

PART2_AVAILABLE = False
PART2_ERROR = ""
try:
    from audio_renderer import run_pipeline as audio_run_pipeline
    PART2_AVAILABLE = True
except ImportError as _e:
    PART2_ERROR = str(_e)

# ── import Part 3's renderer ───────────────────────────────────────────────────
from scene_renderer import render_scene, check_ffmpeg


# ── colour palette ─────────────────────────────────────────────────────────────
BG     = "#1e1e2e"
BG2    = "#181825"
FG     = "#cdd6f4"
ACCENT = "#89b4fa"
GREEN  = "#a6e3a1"
ORANGE = "#fab387"
MUTED  = "#a6adc8"
ENTRY  = "#313244"


# ── audio/video merge helper ──────────────────────────────────────────────────

def _ffmpeg_merge(video_path: str, audio_path: str, out_path: str, log=print):
    """Mux a video file and an audio file into a single MP4 using FFmpeg."""
    log(f"  Merging audio + video -> {Path(out_path).name}")
    cmd = [
        "ffmpeg", "-y",
        "-i", video_path,
        "-i", audio_path,
        "-c:v", "copy",
        "-c:a", "aac",
        "-shortest",
        out_path,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"FFmpeg merge error:\n{result.stderr[-800:]}")
    log(f"  Merged file: {out_path}")


# ── main app ───────────────────────────────────────────────────────────────────

class Studio(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Script-to-Scene Studio")
        self.geometry("960x1000")
        self.minsize(860, 920)
        self.configure(bg=BG)
        self._scene: dict | None = None
        self._build_ui()

    # ── layout ────────────────────────────────────────────────────────────────

    def _build_ui(self):
        # header
        tk.Label(self, text="Script-to-Scene Studio",
                 bg=BG, fg="#cba6f7", font=("Segoe UI", 17, "bold")).pack(pady=(16, 2))
        tk.Label(self,
                 text="Step 1: generate script  →  Step 2: render audio  →  Step 3: render video",
                 bg=BG, fg=MUTED, font=("Segoe UI", 9)).pack(pady=(0, 10))
        ttk.Separator(self).pack(fill="x", padx=16)

        # ── step 1 ────────────────────────────────────────────────────────────
        self._header("Step 1 — Write Your Script", ACCENT)

        form = tk.Frame(self, bg=BG)
        form.pack(fill="x", padx=20, pady=(4, 0))
        form.columnconfigure(1, weight=1)

        tk.Label(form, text="Story idea:", bg=BG, fg=FG,
                 font=("Segoe UI", 10)).grid(row=0, column=0, sticky="nw",
                                              padx=(0, 10), pady=4)
        self.story_box = tk.Text(form, height=3, wrap="word", bg=ENTRY, fg=FG,
                                  insertbackground=FG, relief="flat",
                                  font=("Segoe UI", 10))
        self.story_box.grid(row=0, column=1, sticky="ew", pady=4)

        tk.Label(form, text="Theme:", bg=BG, fg=FG,
                 font=("Segoe UI", 10)).grid(row=1, column=0, sticky="w",
                                              padx=(0, 10), pady=4)
        self.theme_var = tk.StringVar()
        tk.Entry(form, textvariable=self.theme_var, bg=ENTRY, fg=FG,
                 insertbackground=FG, relief="flat",
                 font=("Segoe UI", 10)).grid(row=1, column=1, sticky="ew", pady=4)

        opts = tk.Frame(form, bg=BG)
        opts.grid(row=2, column=1, sticky="w", pady=4)
        tk.Label(opts, text="Characters (1-5):", bg=BG, fg=FG,
                 font=("Segoe UI", 10)).pack(side="left", padx=(0, 6))
        self.chars_var = tk.StringVar(value="2")
        ttk.Spinbox(opts, from_=1, to=5, textvariable=self.chars_var,
                    width=5).pack(side="left", padx=(0, 20))
        tk.Label(opts, text="Duration (min):", bg=BG, fg=FG,
                 font=("Segoe UI", 10)).pack(side="left", padx=(0, 6))
        self.dur_var = tk.StringVar(value="1")
        tk.Entry(opts, textvariable=self.dur_var, width=6, bg=ENTRY, fg=FG,
                 insertbackground=FG, relief="flat").pack(side="left")

        btn1 = tk.Frame(form, bg=BG)
        btn1.grid(row=3, column=1, sticky="w", pady=(8, 4))
        self.gen_btn = self._btn(btn1, "Generate Script  ▶", self._start_generate, ACCENT)
        self.gen_btn.pack(side="left", padx=(0, 10))
        self._btn(btn1, "Load JSON  ↑", self._load_json, ENTRY).pack(side="left", padx=(0, 10))
        self.save_json_btn = self._btn(btn1, "Save JSON", self._save_json, ENTRY)
        self.save_json_btn.pack(side="left")
        self.save_json_btn.configure(state="disabled")

        tk.Label(self, text="Script Preview:", bg=BG, fg=MUTED,
                 font=("Segoe UI", 9, "italic")).pack(anchor="w", padx=20, pady=(8, 2))
        self.preview = scrolledtext.ScrolledText(
            self, height=8, state="disabled",
            font=("Courier New", 9), bg=BG2, fg=FG, relief="flat",
        )
        self.preview.pack(fill="x", padx=20)

        ttk.Separator(self).pack(fill="x", padx=16, pady=10)

        # ── step 2: audio (optional) ──────────────────────────────────────────
        self._header("Step 2 — Audio Rendering  (Optional)", ORANGE)

        audio_frame = tk.Frame(self, bg=BG)
        audio_frame.pack(fill="x", padx=20, pady=(2, 8))
        audio_frame.columnconfigure(1, weight=1)

        self.audio_var = tk.BooleanVar(value=False)
        self.audio_check = tk.Checkbutton(
            audio_frame,
            text="Enable voice audio (requires ElevenLabs API key)",
            variable=self.audio_var,
            command=self._toggle_audio,
            bg=BG, fg=FG, selectcolor=ENTRY,
            activebackground=BG, activeforeground=FG,
            font=("Segoe UI", 10),
        )
        self.audio_check.grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 6))

        tk.Label(audio_frame, text="ElevenLabs key:", bg=BG, fg=FG,
                 font=("Segoe UI", 10)).grid(row=1, column=0, sticky="w",
                                              padx=(0, 10), pady=2)
        self.apikey_var = tk.StringVar()
        self.apikey_entry = tk.Entry(
            audio_frame, textvariable=self.apikey_var,
            show="*", bg=ENTRY, fg=FG, insertbackground=FG,
            relief="flat", font=("Segoe UI", 10), state="disabled",
        )
        self.apikey_entry.grid(row=1, column=1, sticky="ew", pady=2)

        if not PART2_AVAILABLE:
            tk.Label(
                audio_frame,
                text=f"  Part 2 unavailable — install its dependencies first:  "
                     f"pip install pydub elevenlabs",
                bg=BG, fg="#f38ba8", font=("Segoe UI", 8),
            ).grid(row=2, column=0, columnspan=2, sticky="w", pady=(4, 0))
            self.audio_check.configure(state="disabled")

        ttk.Separator(self).pack(fill="x", padx=16, pady=10)

        # ── step 3: render ────────────────────────────────────────────────────
        self._header("Step 3 — Render Scene", GREEN)

        out_row = tk.Frame(self, bg=BG)
        out_row.pack(fill="x", padx=20, pady=(4, 10))
        tk.Label(out_row, text="Output folder:", bg=BG, fg=FG,
                 font=("Segoe UI", 10)).pack(side="left", padx=(0, 8))
        self.out_var = tk.StringVar(value="output")
        tk.Entry(out_row, textvariable=self.out_var, width=48, bg=ENTRY, fg=FG,
                 insertbackground=FG, relief="flat").pack(side="left", ipady=3, padx=(0, 8))
        self._btn(out_row, "Browse…", self._browse_out, ENTRY).pack(side="left")

        self.render_btn = self._btn(self, "▶  Render Scene", self._start_render, GREEN)
        self.render_btn.configure(font=("Segoe UI", 12, "bold"), pady=8,
                                   padx=18, state="disabled")
        self.render_btn.pack(pady=(0, 8))

        sty = ttk.Style()
        sty.theme_use("default")
        sty.configure("G.Horizontal.TProgressbar", troughcolor=ENTRY, background=GREEN)
        self.progress = ttk.Progressbar(self, mode="indeterminate", length=880,
                                         style="G.Horizontal.TProgressbar")
        self.progress.pack(padx=20)

        tk.Label(self, text="Log:", bg=BG, fg=MUTED,
                 font=("Segoe UI", 9, "italic")).pack(anchor="w", padx=20, pady=(8, 2))
        self.log = scrolledtext.ScrolledText(
            self, height=10, state="disabled",
            font=("Courier New", 9), bg=BG2, fg=FG, relief="flat",
        )
        self.log.pack(fill="both", expand=True, padx=20, pady=(0, 16))

    # ── widget helpers ────────────────────────────────────────────────────────

    def _header(self, text, color):
        tk.Label(self, text=text, bg=BG, fg=color,
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=20, pady=(6, 4))

    def _btn(self, parent, text, cmd, bg):
        fg_col = "#1e1e2e" if bg not in (ENTRY,) else FG
        return tk.Button(parent, text=text, command=cmd, bg=bg, fg=fg_col,
                         activebackground=bg, relief="flat",
                         font=("Segoe UI", 10), cursor="hand2", padx=6, pady=4)

    def _write_log(self, msg):
        self.log.configure(state="normal")
        self.log.insert("end", msg + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")
        self.update_idletasks()

    def _write_preview(self, text):
        self.preview.configure(state="normal")
        self.preview.delete("1.0", "end")
        self.preview.insert("end", text)
        self.preview.configure(state="disabled")

    def _toggle_audio(self):
        if self.audio_var.get() and PART2_AVAILABLE:
            self.apikey_entry.configure(state="normal")
        else:
            self.apikey_entry.configure(state="disabled")

    def _browse_out(self):
        p = filedialog.askdirectory(title="Select output folder")
        if p:
            self.out_var.set(p)

    def _load_json(self):
        p = filedialog.askopenfilename(
            title="Select a script JSON file",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if not p:
            return
        try:
            with open(p, encoding="utf-8") as f:
                scene = json.load(f)
            if "dialogue_with_timing" not in scene and "dialogue" in scene:
                if PART1_AVAILABLE:
                    gen = StorySceneGenerator(use_happy_cleanup=False)
                    scene["dialogue_with_timing"] = gen.estimate_dialogue_timing(scene["dialogue"])
                else:
                    # simple fallback: 3 s per line
                    scene["dialogue_with_timing"] = [
                        {**ln, "estimated_duration_sec": 3.0, "word_count": len(ln.get("text", "").split())}
                        for ln in scene["dialogue"]
                    ]
            self._gen_done(scene)
        except Exception as e:
            messagebox.showerror("Load error", f"Could not load file:\n{e}")

    def _save_json(self):
        if not self._scene:
            return
        p = filedialog.asksaveasfilename(defaultextension=".json",
                                          filetypes=[("JSON files", "*.json")])
        if p:
            with open(p, "w", encoding="utf-8") as f:
                json.dump(self._scene, f, indent=2, ensure_ascii=False)
            messagebox.showinfo("Saved", f"Script saved to:\n{p}")

    # ── step 1: generate script ───────────────────────────────────────────────

    def _start_generate(self):
        if not PART1_AVAILABLE:
            messagebox.showerror(
                "Missing dependency",
                f"Could not import Part 1 script generator:\n{PART1_ERROR}\n\n"
                "Install Part 1 dependencies:\n"
                "pip install ollama happytransformer transformers torch",
            )
            return

        story = self.story_box.get("1.0", "end").strip()
        theme = self.theme_var.get().strip()
        if not story:
            messagebox.showerror("Missing input", "Please enter a story idea.")
            return
        if not theme:
            messagebox.showerror("Missing input", "Please enter a theme.")
            return
        try:
            chars = int(self.chars_var.get())
            dur = float(self.dur_var.get())
        except ValueError:
            messagebox.showerror("Input error",
                                  "Characters must be a whole number; duration a decimal.")
            return

        self.gen_btn.configure(state="disabled")
        self.render_btn.configure(state="disabled")
        self.save_json_btn.configure(state="disabled")
        self._write_preview("Generating script with Ollama / Llama3 — please wait...")

        def run():
            try:
                gen = StorySceneGenerator(
                    ollama_model="llama3",
                    use_happy_cleanup=False,
                    max_generation_retries=3,
                )
                scene = gen.generate_scene(story, theme, chars, dur)
                self.after(0, self._gen_done, scene)
            except Exception as e:
                self.after(0, self._gen_error, str(e))

        threading.Thread(target=run, daemon=True).start()

    def _gen_done(self, scene):
        self._scene = scene
        lines = [
            f"TITLE:    {scene.get('title', '')}",
            f"THEME:    {scene.get('theme', '')}",
            f"SUMMARY:  {scene.get('scene_summary', '')}",
            "",
            "CHARACTERS:",
        ]
        for c in scene.get("characters", []):
            lines.append(f"  {c['name']} — {c['role']} ({c['personality']})")
        lines += ["", "DIALOGUE:"]
        for i, d in enumerate(scene.get("dialogue_with_timing", []), 1):
            lines.append(f"  {i:02d}. {d['speaker']}: {d['text']}")
        lines += [
            "",
            f"Lines: {len(scene.get('dialogue', []))}   "
            f"Est. duration: {scene.get('total_estimated_dialogue_sec', '?')}s",
        ]
        self._write_preview("\n".join(lines))
        self.gen_btn.configure(state="normal")
        self.save_json_btn.configure(state="normal")
        self.render_btn.configure(state="normal")

    def _gen_error(self, err):
        self._write_preview(f"ERROR:\n{err}")
        self.gen_btn.configure(state="normal")
        messagebox.showerror("Generation failed", err[:500])

    # ── step 2+3: audio + video render ────────────────────────────────────────

    def _start_render(self):
        if not self._scene:
            messagebox.showerror("No script", "Generate or load a script first (Step 1).")
            return
        if not check_ffmpeg():
            messagebox.showerror(
                "FFmpeg missing",
                "FFmpeg not found on PATH.\n"
                "Download: https://ffmpeg.org/download.html",
            )
            return

        use_audio = self.audio_var.get() and PART2_AVAILABLE
        api_key = self.apikey_var.get().strip()
        if use_audio and not api_key:
            messagebox.showerror("Missing API key",
                                  "Enter your ElevenLabs API key to enable audio.")
            return

        out_dir = self.out_var.get().strip() or "output"
        self.render_btn.configure(state="disabled")
        self.gen_btn.configure(state="disabled")
        self.progress.start(10)
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")

        scene = self._scene

        def run():
            tmp = None
            audio_mp3 = None
            try:
                # write scene to a temp JSON (both Part 2 and Part 3 read from a file)
                with tempfile.NamedTemporaryFile(
                    mode="w", suffix=".json", delete=False, encoding="utf-8"
                ) as f:
                    json.dump(scene, f, ensure_ascii=False)
                    tmp = f.name

                # ── Part 2: audio rendering ────────────────────────────────
                if use_audio:
                    self._write_log("\n=== Part 2: Audio Rendering ===")
                    audio_out = str(Path(out_dir) / "audio")
                    try:
                        # capture Part 2's print() output and forward to our log
                        buf = io.StringIO()
                        with contextlib.redirect_stdout(buf):
                            metadata = audio_run_pipeline(
                                script_path=tmp,
                                api_key=api_key,
                                output_dir=audio_out,
                            )
                        for line in buf.getvalue().splitlines():
                            self._write_log(line)

                        safe = metadata["title"].replace(" ", "_")
                        audio_mp3 = str(Path(audio_out) / f"{safe}_final.mp3")
                        self._write_log(f"  Audio ready: {audio_mp3}")
                    except Exception as ae:
                        self._write_log(f"  [WARN] Audio rendering failed: {ae}")
                        self._write_log("  Continuing without audio...")
                        audio_mp3 = None

                # ── Part 3: video rendering ────────────────────────────────
                self._write_log("\n=== Part 3: Video Rendering ===")
                video_path = render_scene(tmp, out_dir, log=self._write_log)

                # ── merge audio + video ────────────────────────────────────
                if audio_mp3 and Path(audio_mp3).exists():
                    self._write_log("\n=== Merging Audio + Video ===")
                    vp = Path(video_path)
                    merged = str(vp.parent / f"{vp.stem}_with_audio.mp4")
                    try:
                        _ffmpeg_merge(video_path, audio_mp3, merged, log=self._write_log)
                        self.after(0, self._render_done, merged)
                    except Exception as me:
                        self._write_log(f"  [WARN] Merge failed: {me}")
                        self._write_log("  Final output is video-only.")
                        self.after(0, self._render_done, video_path)
                else:
                    self.after(0, self._render_done, video_path)

            except Exception as e:
                self._write_log(f"\nERROR: {e}")
                self.after(0, self._render_error, str(e))
            finally:
                if tmp and os.path.exists(tmp):
                    os.unlink(tmp)

        threading.Thread(target=run, daemon=True).start()

    def _render_done(self, output_path):
        self.render_btn.configure(state="normal")
        self.gen_btn.configure(state="normal")
        self.progress.stop()
        messagebox.showinfo("Done!", f"Output saved to:\n{Path(output_path).resolve()}")

    def _render_error(self, err):
        self.render_btn.configure(state="normal")
        self.gen_btn.configure(state="normal")
        self.progress.stop()
        messagebox.showerror("Render failed", err[:500])


if __name__ == "__main__":
    app = Studio()
    app.mainloop()
