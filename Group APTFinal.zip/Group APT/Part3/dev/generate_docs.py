#!/usr/bin/env python3
"""
Generates Part3_Documentation.pdf — run once from the Part3 folder:
    python generate_docs.py
"""

import io
import sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, str(Path(__file__).parent))
from scene_renderer import (
    render_title_card, composite_frame, ken_burns, apply_cinematic,
    draw_character_thumbs, draw_subtitles,
    get_font, _rounded_mask,
    WIDTH, HEIGHT, KB_W, KB_H,
    THUMB_W, THUMB_H, THUMB_MARGIN,
    LETTERBOX_H, CONTENT_BOTTOM,
    CHARACTER_PALETTE,
)
from fpdf import FPDF, XPos, YPos


# ── diagram / sample-frame generators ─────────────────────────────────────────

def _to_bytes(img: Image.Image) -> bytes:
    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="PNG")
    return buf.getvalue()


def _gradient(ca, cb, w=WIDTH, h=HEIGHT) -> Image.Image:
    img = Image.new("RGB", (w, h))
    draw = ImageDraw.Draw(img)
    for y in range(h):
        t = y / h
        r = int(ca[0] + t * (cb[0] - ca[0]))
        g = int(ca[1] + t * (cb[1] - ca[1]))
        b = int(ca[2] + t * (cb[2] - ca[2]))
        draw.line([(0, y), (w, y)], fill=(r, g, b))
    return img


def make_pipeline_diagram() -> bytes:
    W, H = 1180, 220
    img = Image.new("RGB", (W, H), (22, 22, 30))
    draw = ImageDraw.Draw(img)
    steps = [
        ("Script\nJSON", (70, 110, 190)),
        ("Ollama\nPrompts", (110, 70, 190)),
        ("Pollinations\nImages", (55, 150, 110)),
        ("Pillow\nFrames", (185, 130, 45)),
        ("FFmpeg\nVideo", (185, 65, 65)),
    ]
    bw, bh = 170, 90
    gap = (W - len(steps) * bw) // (len(steps) + 1)
    yc = H // 2
    fn = get_font(19)
    fn_num = get_font(12)
    for i, (label, col) in enumerate(steps):
        x = gap + i * (bw + gap)
        y = yc - bh // 2
        draw.rounded_rectangle([(x+3,y+3),(x+bw+3,y+bh+3)], radius=10, fill=(0,0,0))
        draw.rounded_rectangle([(x,y),(x+bw,y+bh)], radius=10, fill=col)
        draw.text((x+bw//2, y+12), f"Step {i+1}", font=fn_num,
                  fill=(255,255,255,160), anchor="mm")
        draw.multiline_text((x+bw//2, y+bh//2+6), label, font=fn,
                            fill=(255,255,255), anchor="mm", align="center")
        if i < len(steps)-1:
            ax = x+bw+3
            draw.line([(ax,yc),(ax+gap-6,yc)], fill=(155,155,155), width=3)
            draw.polygon([(ax+gap-6,yc-8),(ax+gap-6,yc+8),(ax+gap+4,yc)],
                         fill=(155,155,155))
    return _to_bytes(img)


def make_layout_diagram() -> bytes:
    """Annotated diagram of the current cinematic frame layout."""
    W, H = 960, 540
    sx, sy = W/WIDTH, H/HEIGHT

    img = Image.new("RGB", (W, H), (15, 15, 25))
    draw = ImageDraw.Draw(img)
    f = get_font(16)
    fs = get_font(12)

    # background
    draw.rectangle([(0,0),(W-1,H-1)], outline=(70,130,210), width=2)
    draw.text((10,8), "AI Scene Image per dialogue line (1280x720)", font=f,
              fill=(70,130,210))

    # letterbox bars
    lb = int(LETTERBOX_H * sy)
    draw.rectangle([(0,0),(W,lb)], fill=(0,0,0))
    draw.rectangle([(0,H-lb),(W,H)], fill=(0,0,0))
    draw.text((W//2, lb//2), "Letterbox bar", font=fs, fill=(180,180,180), anchor="mm")
    draw.text((W//2, H-lb//2), "Letterbox bar", font=fs, fill=(180,180,180), anchor="mm")

    # vignette label
    draw.text((W//2, lb+18), "Vignette (dark gradient from all edges)", font=fs,
              fill=(150,150,150), anchor="mm")

    # side thumbnails
    tw = int(THUMB_W * sx * 1.1)
    th = int(THUMB_H * sy * 1.1)
    thumb_bottom = int((CONTENT_BOTTOM - 95) * sy)
    for side, col, lbl in [
        (THUMB_MARGIN, (255,210,90), "Active\nthumbnail\n(coloured border)"),
        (W - THUMB_MARGIN - tw, (100,210,255), "Inactive\nthumbnail\n(dimmed)"),
    ]:
        draw.rounded_rectangle([(int(side*sx), thumb_bottom-th),
                                 (int(side*sx)+tw, thumb_bottom)],
                               radius=8, fill=(60,45,80,180), outline=col, width=2)
        draw.multiline_text((int(side*sx)+tw//2, thumb_bottom-th//2), lbl,
                            font=fs, fill=(255,255,255), anchor="mm", align="center")

    # subtitle area
    sub_y = int((CONTENT_BOTTOM - 60) * sy)
    draw.text((W//2, sub_y-18), "Speaker Name (coloured)", font=fs,
              fill=(255,210,90), anchor="mm")
    draw.text((W//2, sub_y+4), "Dialogue text — white with black outline", font=f,
              fill=(255,255,255), anchor="mm")
    draw.text((W//2, sub_y+22), "(centred, no background box)", font=fs,
              fill=(160,160,160), anchor="mm")

    return _to_bytes(img)


def _make_placeholder_thumb(color, name) -> Image.Image:
    img = Image.new("RGBA", (THUMB_W, THUMB_H), (*color, 255))
    draw = ImageDraw.Draw(img)
    for y in range(THUMB_H):
        draw.line([(0,y),(THUMB_W,y)], fill=(0,0,0,int(40+y*0.6)))
    cx = THUMB_W//2
    draw.ellipse([(cx-18,12),(cx+18,48)], fill=(220,190,160,220))
    draw.ellipse([(cx-20,42),(cx+20,THUMB_H-6)], fill=(50,38,65,200))
    img.putalpha(_rounded_mask(THUMB_W, THUMB_H, 10))
    return img


def make_sample_title_frame() -> bytes:
    bg = _gradient((35,20,55),(10,5,30), KB_W, KB_H)
    crop = ken_burns(bg, 0.0, 0)
    frame = render_title_card(crop, "Mystic Duel", "tense",
                               "Two rival magicians, Lyra and Kael, engage in a mystical duel.")
    return _to_bytes(frame.resize((960, 540)))


def make_sample_dialogue_frame(active="Lyra") -> bytes:
    bg = _gradient((25,15,45),(8,5,25), KB_W, KB_H)
    crop = ken_burns(bg, 0.4, 1)
    color = CHARACTER_PALETTE[0] if active == "Lyra" else CHARACTER_PALETTE[1]
    portraits = {
        "Lyra": _make_placeholder_thumb((160,60,190), "Lyra"),
        "Kael": _make_placeholder_thumb((60,100,200), "Kael"),
    }
    char_colors = {"Lyra": CHARACTER_PALETTE[0], "Kael": CHARACTER_PALETTE[1]}
    texts = {
        "Lyra": "You underestimate my power, Kael. The shadows will be your downfall.",
        "Kael": "Ha! You think darkness can defeat fire? I'll incinerate you!",
    }
    frame = composite_frame(crop, active, texts[active], len(texts[active]),
                            48, color, portraits, ["Lyra","Kael"], char_colors)
    return _to_bytes(frame.resize((960, 540)))


# ── PDF builder ────────────────────────────────────────────────────────────────

FONT_BODY = "Arial"
MARGIN = 20
PAGE_W = 210
CONTENT_W = PAGE_W - 2 * MARGIN

_ARIAL    = "C:/Windows/Fonts/arial.ttf"
_ARIAL_B  = "C:/Windows/Fonts/arialbd.ttf"
_ARIAL_I  = "C:/Windows/Fonts/ariali.ttf"
_ARIAL_BI = "C:/Windows/Fonts/arialbi.ttf"


class DocPDF(FPDF):
    def __init__(self):
        super().__init__(orientation="P", unit="mm", format="A4")
        self.add_font(FONT_BODY, fname=_ARIAL)
        self.add_font(FONT_BODY, style="B", fname=_ARIAL_B)
        self.add_font(FONT_BODY, style="I", fname=_ARIAL_I)
        self.add_font(FONT_BODY, style="BI", fname=_ARIAL_BI)
        self.set_margins(MARGIN, MARGIN, MARGIN)
        self.set_auto_page_break(True, margin=18)

    def header(self):
        if self.page_no() == 1:
            return
        self.set_font(FONT_BODY, "I", 8)
        self.set_text_color(140,140,140)
        self.cell(0, 6, "Part 3: Visual Rendering & Assembly - ICS2000", align="L")
        self.cell(0, 6, f"Page {self.page_no()}", align="R",
                  new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        self.set_draw_color(200,200,200)
        self.line(MARGIN, self.get_y(), PAGE_W-MARGIN, self.get_y())
        self.ln(3)
        self.set_text_color(0,0,0)

    def footer(self):
        if self.page_no() == 1:
            return
        self.set_y(-13)
        self.set_font(FONT_BODY, "I", 8)
        self.set_text_color(160,160,160)
        self.cell(0, 6, "Script-to-Scene Generator - Group APT Project", align="C")

    def h1(self, text):
        self.ln(4)
        self.set_font(FONT_BODY, "B", 16)
        self.set_text_color(40,80,160)
        self.cell(0, 10, text, new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        self.set_draw_color(40,80,160)
        self.line(MARGIN, self.get_y(), PAGE_W-MARGIN, self.get_y())
        self.ln(3)
        self.set_text_color(0,0,0)

    def h2(self, text):
        self.ln(3)
        self.set_font(FONT_BODY, "B", 12)
        self.set_text_color(60,60,60)
        self.cell(0, 8, text, new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        self.set_text_color(0,0,0)
        self.ln(1)

    def body(self, text, size=10.5):
        self.set_font(FONT_BODY, "", size)
        self.set_text_color(30,30,30)
        self.multi_cell(CONTENT_W, 5.5, text)
        self.ln(2)

    def bullet(self, items, size=10.5):
        self.set_font(FONT_BODY, "", size)
        self.set_text_color(30,30,30)
        for item in items:
            self.cell(6, 5.5, "•")
            self.multi_cell(CONTENT_W-6, 5.5, item)
        self.ln(2)

    def code(self, text):
        self.set_fill_color(240,240,245)
        self.set_font("Courier", "", 8.5)
        self.set_text_color(40,40,80)
        self.multi_cell(CONTENT_W, 4.8, text, fill=True)
        self.set_font(FONT_BODY, "", 10.5)
        self.set_text_color(30,30,30)
        self.ln(2)

    def embed_image(self, img_bytes, caption, w_mm=None):
        if w_mm is None:
            w_mm = CONTENT_W
        self.image(io.BytesIO(img_bytes), x=MARGIN, w=w_mm)
        self.set_font(FONT_BODY, "I", 9)
        self.set_text_color(100,100,100)
        self.multi_cell(CONTENT_W, 5, caption, align="C")
        self.set_text_color(30,30,30)
        self.ln(3)

    def callout(self, text, color=(230,240,255)):
        self.set_fill_color(*color)
        self.set_font(FONT_BODY, "I", 10)
        self.set_text_color(50,50,120)
        self.multi_cell(CONTENT_W, 5.5, text, fill=True)
        self.set_text_color(30,30,30)
        self.set_font(FONT_BODY, "", 10.5)
        self.ln(3)


# ── document content ───────────────────────────────────────────────────────────

def build_pdf(out_path: str):
    print("Generating diagrams and sample frames...")
    pipeline_img   = make_pipeline_diagram()
    layout_img     = make_layout_diagram()
    title_frame    = make_sample_title_frame()
    frame_lyra     = make_sample_dialogue_frame("Lyra")
    frame_kael     = make_sample_dialogue_frame("Kael")
    print("All images ready. Building PDF...")

    pdf = DocPDF()

    # ── TITLE PAGE ─────────────────────────────────────────────────────────────
    pdf.add_page()
    pdf.ln(30)
    pdf.set_font(FONT_BODY, "B", 26)
    pdf.set_text_color(40,80,160)
    pdf.cell(0, 14, "Script-to-Scene Generator", align="C",
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font(FONT_BODY, "B", 17)
    pdf.set_text_color(80,80,80)
    pdf.cell(0, 10, "Part 3: Visual Rendering & Assembly", align="C",
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.ln(10)
    pdf.set_draw_color(40,80,160)
    pdf.set_line_width(0.8)
    pdf.line(MARGIN+20, pdf.get_y(), PAGE_W-MARGIN-20, pdf.get_y())
    pdf.ln(12)
    for k, v in [
        ("Student",    "Malcolm Debattista"),
        ("Supervisor", "Prof. Matthew Montebello"),
        ("Module",     "ICS2000 - Generative AI, Performing Arts"),
        ("Date",       "April 2026"),
    ]:
        pdf.set_font(FONT_BODY, "B", 12)
        pdf.set_text_color(50,50,50)
        pdf.cell(40, 8, f"{k}:", align="R")
        pdf.set_font(FONT_BODY, "", 12)
        pdf.cell(0, 8, f"  {v}", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.ln(14)
    pdf.set_font(FONT_BODY, "I", 10)
    pdf.set_text_color(120,120,120)
    pdf.multi_cell(CONTENT_W, 5.5,
        "This document covers the design, implementation, and evaluation of the visual "
        "rendering and video assembly component of the Script-to-Scene Generator project.",
        align="C")

    # ── 1. INTRODUCTION ────────────────────────────────────────────────────────
    pdf.add_page()
    pdf.h1("1. Introduction")
    pdf.body(
        "The Script-to-Scene Generator is a group project that transforms a short AI-written "
        "script into a fully rendered audiovisual micro-scene. The project is divided into three "
        "parts: script and dialogue generation (Part 1), audio rendering via text-to-speech "
        "(Part 2), and visual rendering and video assembly (Part 3). This document covers Part 3."
    )
    pdf.body(
        "Part 3 takes the structured JSON output produced by Part 1 and automatically generates "
        "a unique AI scene image for each line of dialogue, downloads character portrait thumbnails, "
        "and composes them into a cinematic animated video with letterbox bars, vignette, "
        "movie-style subtitles, Ken Burns camera movement, and typewriter text effects. "
        "The final output is an MP4 file ready to receive the audio track from Part 2."
    )

    pdf.h2("1.1 Objectives")
    pdf.bullet([
        "Accept any JSON script file produced by Part 1 without modification.",
        "Generate a unique AI background image per dialogue line showing the scene action.",
        "Generate an individual AI portrait thumbnail for each character.",
        "Apply cinematic visual effects: letterbox bars, vignette, Ken Burns pan, crossfades.",
        "Render movie-style centred subtitles with typewriter effect and speaker colour coding.",
        "Assemble all frames into a playable MP4 using FFmpeg.",
        "Provide a unified studio GUI where users can write or load a script and render in one window.",
    ])

    pdf.h2("1.2 Scope and Constraints")
    pdf.body(
        "Part 3 is fully independent of Part 2 — the video is produced with no audio track, "
        "which can be muxed in later with a single FFmpeg command. All image generation uses "
        "Pollinations.ai, a free public API requiring no account or API key, making the system "
        "fully reproducible at zero cost. Downloads are performed sequentially with automatic "
        "retry to respect the API's rate limits."
    )

    # ── 2. LITERATURE REVIEW ───────────────────────────────────────────────────
    pdf.h1("2. Literature Review")

    pdf.h2("2.1 AI Image Generation")
    pdf.body(
        "Generative image models such as Stable Diffusion (Rombach et al., 2022) have made it "
        "possible to produce high-quality images from natural-language prompts. This project uses "
        "Pollinations.ai, a free public wrapper around the Flux diffusion model, to generate both "
        "scene environment images and character portrait images without requiring local GPU hardware "
        "or paid API access."
    )

    pdf.h2("2.2 Prompt Engineering")
    pdf.body(
        "Image quality is highly sensitive to prompt wording. Effective prompts use "
        "cinematography terminology: golden hour, shallow depth of field, anamorphic lens, "
        "and avoid describing characters directly in background prompts (Oppenlaender, 2022). "
        "This system delegates prompt authoring to Ollama/Llama3, which interprets each "
        "dialogue line in context and generates an appropriate short cinematic prompt."
    )

    pdf.h2("2.3 Cinematic Language and the Ken Burns Effect")
    pdf.body(
        "The Ken Burns effect is a slow pan or zoom applied to a still image to simulate camera "
        "movement, widely used in documentary filmmaking (Burns, 1990). In this system the "
        "background image is pre-scaled to 1440x810 pixels and a 1280x720 crop window slowly "
        "drifts across it, with a different direction for each dialogue line to vary the "
        "visual rhythm of the scene."
    )

    pdf.h2("2.4 Visual Novel Conventions")
    pdf.body(
        "Visual novels use character sprites overlaid on background art with a dialogue box at "
        "the bottom of the screen. The active speaker is highlighted while others dim "
        "(Cavallaro, 2010). This system adapts these conventions in a cinematic style: "
        "character thumbnails are pinned to the screen edges, the active speaker is highlighted "
        "with a coloured border, and subtitles replace a traditional dialogue box."
    )

    pdf.h2("2.5 Letterboxing and Vignetting")
    pdf.body(
        "Letterbox bars (black bars at the top and bottom of the frame) simulate a 2.39:1 "
        "anamorphic aspect ratio used in major motion pictures. Vignetting — darkening of the "
        "frame edges — is a characteristic of wide-aperture cinema lenses and is used "
        "stylistically to draw the viewer's eye toward the centre of the frame. Both effects "
        "are pre-computed once and composited onto every frame."
    )

    pdf.h2("2.6 FFmpeg and Python Pillow")
    pdf.body(
        "FFmpeg (Bellard, 2000) assembles PNG frame sequences into H.264/AVC MP4 files "
        "compatible with all modern players. Pillow (Clark, 2013) provides the RGBA compositing, "
        "font rendering, rounded rectangle primitives, and brightness/colour enhancement used "
        "to generate each frame."
    )

    # ── 3. METHODOLOGY & DESIGN ────────────────────────────────────────────────
    pdf.add_page()
    pdf.h1("3. Methodology & Design")

    pdf.h2("3.1 Pipeline Architecture")
    pdf.body(
        "The system follows a five-stage linear pipeline. Each stage has a single well-defined "
        "input and output, making stages independently testable and replaceable."
    )
    pdf.embed_image(pipeline_img,
                    "Figure 1: Five-stage rendering pipeline from script JSON to output MP4.")

    pdf.h2("3.2 Input Format")
    pdf.body("The system reads JSON files produced by Part 1. Key fields used:")
    pdf.code(
        '{\n'
        '  "title":               "Mystic Duel",\n'
        '  "theme":               "tense",\n'
        '  "scene_summary":       "Two rival magicians duel...",\n'
        '  "characters":          [ { "name": "Lyra", "role": "Illusionist", ... } ],\n'
        '  "dialogue_with_timing": [\n'
        '    { "speaker": "Lyra", "text": "...", "estimated_duration_sec": 4.4 }\n'
        '  ]\n'
        '}'
    )

    pdf.h2("3.3 Per-Line Scene Images")
    pdf.body(
        "A key design decision is generating one background image per dialogue line rather than "
        "one image for the whole scene. For each line Ollama is prompted to describe what the "
        "camera should show during that specific moment — the environment, action, and mood. "
        "This makes the video visually reactive to the narrative: a line about danger generates "
        "a tense dark environment; a joyful line generates warm bright scenery."
    )
    pdf.body(
        "Downloads are performed sequentially with a two-second gap between requests and "
        "automatic retry with exponential backoff on HTTP 429 (rate-limit) responses. "
        "If a download ultimately fails a dark fallback background is used so the render "
        "always completes."
    )

    pdf.h2("3.4 Cinematic Frame Composition")
    pdf.embed_image(layout_img,
                    "Figure 2: Annotated frame layout showing letterbox bars, vignette zone, "
                    "side character thumbnails, and centred subtitle area.")

    pdf.h2("3.4.1 Letterbox and Vignette")
    pdf.body(
        "78-pixel black bars are composited at the top and bottom of every frame, simulating "
        "a 2.39:1 anamorphic ratio. A vignette gradient (pre-computed once at startup) darkens "
        "the frame edges using quadratic falloff over 220 vertical pixels and 160 horizontal pixels."
    )

    pdf.h2("3.4.2 Movie-Style Subtitles")
    pdf.body(
        "Rather than a large semi-transparent dialogue box, subtitles are rendered as centred "
        "white text with a multi-pass black outline, positioned just above the bottom letterbox "
        "bar. The speaker's name appears in their assigned colour above the text. This approach "
        "maximises the visible scene area and more closely resembles commercial film presentation."
    )

    pdf.h2("3.4.3 Character Thumbnails")
    pdf.body(
        "Small character portrait thumbnails (82x116 px) are pinned to the left and right "
        "screen edges. Even-indexed characters appear on the left; odd-indexed on the right. "
        "The active speaker's thumbnail is 12% larger and displays a thin coloured border. "
        "Inactive characters are rendered at 38% opacity so they do not compete with the scene."
    )

    pdf.h2("3.4.4 Animation Effects")
    pdf.bullet([
        "Ken Burns: background pre-scaled to 1440x810; a 1280x720 crop window slowly drifts "
        "across it (different direction per line) giving continuous camera movement.",
        "Typewriter effect: dialogue text types out at 24 characters/second with a blinking cursor.",
        "Crossfade: a 16-frame linear blend transitions between every pair of consecutive lines.",
        "Fade from black: the opening title card fades in over 20 frames.",
    ])

    # ── 4. IMPLEMENTATION ──────────────────────────────────────────────────────
    pdf.add_page()
    pdf.h1("4. Implementation")

    pdf.h2("4.1 Module Structure")
    pdf.bullet([
        "scene_renderer.py - full rendering pipeline and CLI entry point.",
        "studio.py - unified Tkinter GUI: script generation (Part 1) + rendering (Part 3).",
        "scene_renderer_gui.py - standalone renderer-only GUI (legacy, still functional).",
        "generate_docs.py - generates this PDF documentation.",
        "requirements.txt - Python dependencies.",
    ])

    pdf.h2("4.2 studio.py - Unified Interface")
    pdf.body(
        "The studio provides a single window for the complete workflow. Step 1 exposes Part 1's "
        "StorySceneGenerator: the user enters a story idea, theme, character count, and duration, "
        "then clicks Generate Script. The generated script appears in a preview panel. "
        "Alternatively, any existing JSON file can be loaded directly via Load JSON. "
        "Step 2 renders the loaded script by passing it to scene_renderer.render_scene() "
        "via a temporary file, with live log output and a progress bar."
    )

    pdf.h2("4.3 Prompt Generation (generate_line_prompt)")
    pdf.body(
        "For each dialogue line Ollama is given the overall scene context, the character "
        "descriptions, and the specific line of dialogue, and asked to write a 15-25 word "
        "cinematic image prompt describing only the environment. Restricting to environment "
        "prevents characters appearing in the background, which would conflict with the "
        "portrait thumbnail layer. A simple fallback prompt is used if Ollama is unavailable."
    )

    pdf.h2("4.4 Rate-Limited Image Downloading (fetch_with_retry)")
    pdf.body(
        "Images are fetched one at a time with a 2-second gap between requests. On an HTTP 429 "
        "response the function waits (attempt number x 6) seconds before retrying, up to 4 "
        "attempts. This respects Pollinations.ai's rate limits while keeping the pipeline "
        "fully automatic. All images are loaded directly into memory (no intermediate files "
        "are written to disk) — only the final MP4 is saved to the output folder."
    )

    pdf.h2("4.5 Cinematic Compositing")
    pdf.body("Each frame is assembled by the following sequence:")
    pdf.bullet([
        "Ken Burns crop: the pre-scaled background is cropped at a position determined by "
        "progress t (0-1) within the current line and the line's assigned pan direction.",
        "apply_cinematic(): composites the pre-computed vignette overlay then pastes the "
        "letterbox bars.",
        "draw_character_thumbs(): pastes active and inactive portrait thumbnails at the "
        "screen edges.",
        "draw_subtitles(): draws the speaker name and typewriter-limited dialogue text "
        "with outline, centred above the bottom letterbox bar.",
    ])

    pdf.h2("4.6 Video Assembly")
    pdf.body(
        "Frames are written as PNGs into a Python tempfile.TemporaryDirectory (automatically "
        "cleaned up after use). FFmpeg reads the sequence at 24 fps and encodes to H.264 "
        "with CRF 20 and the fast preset, producing a yuv420p MP4 compatible with all "
        "major media players and video editors."
    )
    pdf.code(
        "ffmpeg -y -framerate 24 -i frame_%05d.png\n"
        "       -c:v libx264 -preset fast -crf 20 -pix_fmt yuv420p output.mp4"
    )

    # ── 5. WORKED EXAMPLE ──────────────────────────────────────────────────────
    pdf.add_page()
    pdf.h1("5. Worked Example")
    pdf.body(
        "The following walkthrough uses the magicians.json sample from Part 1 "
        "(title: Mystic Duel, theme: tense, 2 characters, 11 dialogue lines)."
    )

    pdf.h2("5.1 Input")
    pdf.code(
        'Title:      "Mystic Duel"\n'
        'Theme:      "tense"\n'
        'Characters: Lyra (Illusionist), Kael (Pyromancer)\n'
        'Lines:      11   |   Total estimated duration: 45.2s'
    )

    pdf.h2("5.2 Prompt Generation")
    pdf.body("For the first line (Lyra: \"You underestimate my power, Kael.\") "
             "Ollama might produce:")
    pdf.callout(
        '"Ancient stone arena, flickering torchlight, deep shadows, '
        'arcane energy crackling, anamorphic lens, cinematic 8K"',
        color=(235,245,255),
    )
    pdf.body("For Lyra's portrait:")
    pdf.callout(
        '"Female illusionist in dark robes, purple magical aura, '
        'full body portrait, plain dark background, fantasy art"',
        color=(245,235,255),
    )

    pdf.h2("5.3 Title Card")
    pdf.body(
        "The first 3 seconds display a title card with fade-in from black. "
        "The background is the first line's scene image with a dark overlay."
    )
    pdf.embed_image(title_frame, "Figure 3: Rendered title card for Mystic Duel.")

    pdf.h2("5.4 Dialogue Frames")
    pdf.body(
        "For each line the scene background changes, the Ken Burns crop moves, "
        "text types out character by character, and the active speaker's thumbnail highlights."
    )
    pdf.embed_image(frame_lyra,
                    "Figure 4: Lyra speaking. Active thumbnail (left, amber border). "
                    "Kael inactive (right, dimmed). Subtitles centred above letterbox bar.")
    pdf.embed_image(frame_kael,
                    "Figure 5: Kael speaking. Roles reversed - Kael active (right, blue border).")

    pdf.h2("5.5 Output")
    pdf.code(
        "Title card:      3.0s   (72 frames)\n"
        "11 dialogue lines: ~45s (crossfades + typewriter + hold)\n"
        "Total video:    ~48s at 24 fps\n\n"
        "Output file:  output/Mystic_Duel.mp4\n"
        "Image files:  none (all kept in memory, not saved to disk)"
    )

    # ── 6. ETHICAL CONSIDERATIONS ──────────────────────────────────────────────
    pdf.add_page()
    pdf.h1("6. Ethical Considerations")

    pdf.h2("6.1 AI-Generated Imagery and Ownership")
    pdf.body(
        "All visual content is generated by machine learning models. The US Copyright Office "
        "(2023) has indicated that purely AI-generated works without human creative authorship "
        "are not eligible for copyright protection. Users should present output images as "
        "AI-generated and not claim them as original copyrighted works."
    )

    pdf.h2("6.2 Model Bias and Representation")
    pdf.body(
        "Text-to-image models trained on internet data reflect historical biases relating to "
        "gender, ethnicity, and culture. A character described as a 'warrior' may default to "
        "a male representation regardless of specification. Users should review generated "
        "portraits and add explicit descriptors to character prompts where needed to override "
        "biased defaults."
    )

    pdf.h2("6.3 Deepfake and Misuse Risk")
    pdf.body(
        "The pipeline could in principle generate realistic human portraits rather than clearly "
        "fictional characters. Such output could contribute to synthetic media that misrepresents "
        "real individuals. The system is designed for fictional creative contexts and its use to "
        "generate realistic depictions of real people without consent would be unethical and in "
        "some jurisdictions illegal."
    )

    pdf.h2("6.4 Responsible Use of Free Services")
    pdf.body(
        "Pollinations.ai is used as a free public service. The system deliberately downloads "
        "images sequentially with a 2-second delay between requests to avoid overloading the "
        "service. Mass automated generation that degrades availability for other users would "
        "be an irresponsible use of a shared resource."
    )

    pdf.h2("6.5 Transparency and Attribution")
    pdf.body(
        "In any academic, commercial, or public-facing context, output produced by this system "
        "should be clearly labelled as AI-generated, with the models and services used disclosed. "
        "This aligns with the EU AI Act (2024) transparency requirements and academic integrity "
        "standards."
    )

    # ── 7. EVALUATION ──────────────────────────────────────────────────────────
    pdf.add_page()
    pdf.h1("7. Evaluation")

    pdf.h2("7.1 Functional Correctness")
    pdf.body(
        "The system was tested against all three sample scripts from Part 1 "
        "(adventure.json, dogs.json, magicians.json) with 2-3 characters and 5-16 dialogue lines. "
        "In all cases the pipeline completed without error, producing a correctly timed MP4. "
        "Fallback code paths for unavailable Ollama, failed downloads, and missing "
        "dialogue_with_timing fields were all verified."
    )

    pdf.h2("7.2 Rate Limiting Resolution")
    pdf.body(
        "An initial parallel download implementation caused HTTP 429 (Too Many Requests) "
        "errors from Pollinations.ai, causing most images to fail and the video to render "
        "with placeholder backgrounds. This was resolved by switching to sequential downloads "
        "with a 2-second inter-request delay and 4-attempt retry with exponential backoff. "
        "All subsequent test runs achieved 100% successful downloads."
    )

    pdf.h2("7.3 Visual Quality")
    pdf.body(
        "Flux-model images from Pollinations.ai are consistently high resolution and "
        "contextually relevant when given specific cinematic prompts. The per-line image "
        "generation produces meaningful visual variety across a scene. Portrait thumbnails "
        "are less consistent across runs due to the absence of seed control in the public API."
    )

    pdf.h2("7.4 Timing Accuracy")
    pdf.body(
        "Frame counts are derived from estimated_duration_sec values (0.4s per word from "
        "Part 1). The rendered video duration matches the sum of these values to within "
        "one frame. The typewriter effect and crossfades are deducted from the hold duration "
        "so total timing remains accurate."
    )

    pdf.h2("7.5 Performance")
    pdf.body(
        "For a 1-minute script with 15 dialogue lines and 2 characters (17 images total): "
        "prompt generation ~2 min, image downloads ~9 min (17 x 30s sequential), "
        "frame rendering ~3-5 min, FFmpeg ~30s. Total: approximately 15-20 minutes. "
        "The download phase dominates and scales linearly with line count."
    )

    pdf.h2("7.6 Limitations")
    pdf.bullet([
        "Portrait consistency: same character may look different across runs (no seed control).",
        "No lip-sync or character animation — thumbnails are static images.",
        "Requires internet connection for all image generation.",
        "Long scripts (20+ lines) can take 30-60 minutes to render.",
        "Audio integration (Part 2) requires a manual FFmpeg mux step.",
    ])

    # ── 8. RESULTS ─────────────────────────────────────────────────────────────
    pdf.h1("8. Results")
    pdf.body(
        "The system successfully transforms any Part 1 script JSON into a playable MP4 with "
        "the following characteristics:"
    )
    pdf.bullet([
        "1280x720 resolution at 24 fps, H.264 encoded for universal compatibility.",
        "Unique AI-generated scene image per dialogue line, contextually matching the action.",
        "One AI-generated character portrait thumbnail per character.",
        "Cinematic 2.39:1 letterbox bars and edge vignette on every frame.",
        "Movie-style centred subtitles: white text, black outline, speaker name in colour.",
        "Ken Burns camera movement on each line's background (different direction per line).",
        "Typewriter text effect with blinking cursor during typing phase.",
        "16-frame crossfade transitions between every dialogue line.",
        "20-frame fade from black on the opening title card.",
        "Only the final MP4 is written to disk — no intermediate image files.",
    ])
    pdf.body(
        "To add Part 2 audio to the final video:"
    )
    pdf.code(
        "ffmpeg -i Mystic_Duel.mp4 -i audio.wav\n"
        "       -c:v copy -c:a aac -shortest Mystic_Duel_final.mp4"
    )

    # ── 9. CONCLUSION & FUTURE WORK ────────────────────────────────────────────
    pdf.add_page()
    pdf.h1("9. Conclusion & Future Work")

    pdf.h2("9.1 Conclusion")
    pdf.body(
        "Part 3 delivers a fully functional cinematic rendering pipeline that converts any "
        "Part 1 script JSON into an animated video micro-scene without requiring GPU hardware, "
        "paid API keys, or manual creative input. The system generates a unique AI scene image "
        "for every dialogue line, applies professional cinematic effects (letterbox, vignette, "
        "Ken Burns, crossfades, typewriter text), and assembles the result into a universally "
        "compatible MP4 using FFmpeg."
    )
    pdf.body(
        "The unified studio.py GUI allows the full workflow - writing a script with Part 1's "
        "generator or loading an existing JSON, previewing it, and rendering the video - in a "
        "single window without switching between scripts. Rate limiting is handled automatically "
        "with retry logic, and all intermediate assets are kept in memory to keep the output "
        "folder clean."
    )

    pdf.h2("9.2 Future Work")
    pdf.bullet([
        "Audio integration - automatically detect a Part 2 audio file and mux it into "
        "the output without a manual FFmpeg command.",
        "Portrait consistency - run Stable Diffusion locally with a fixed seed and "
        "ControlNet pose conditioning for coherent character appearance across all frames.",
        "Character animation - apply a sinusoidal breathing oscillation to the active "
        "thumbnail's vertical position for a subtle idle animation.",
        "Scene transitions - detect act breaks in the dialogue and insert a longer "
        "cross-dissolve or wipe transition.",
        "Background parallax - apply slow horizontal pan to background independently of "
        "foreground elements for a parallax depth effect.",
        "Subtitle export - generate an SRT file alongside the video for accessibility.",
        "Batch rendering - queue a folder of JSON files for overnight unattended rendering.",
        "Faster downloads - explore Pollinations.ai's higher-rate-limit tiers or "
        "alternative free APIs to reduce total render time for long scripts.",
    ])

    pdf.output(out_path)
    print(f"\nDocumentation written to: {Path(out_path).resolve()}")


if __name__ == "__main__":
    out = Path(__file__).parent / "Part3_Documentation.pdf"
    build_pdf(str(out))
