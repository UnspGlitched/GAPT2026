#!/usr/bin/env python3
"""
Part 3 - Visual Rendering & Assembly
Cinematic micro-scene renderer. Converts a Part 1 script JSON into a movie-style video.

Pipeline:
  1. Load script JSON from Part 1
  2. Use Ollama to write a short cinematic image prompt per dialogue line
  3. Download scene images sequentially from Pollinations.ai (with retry on rate limit)
  4. Render animated frames:
       - Letterbox bars (cinematic 2.39:1 look)
       - Per-line AI scene image with Ken Burns pan (different direction each line)
       - Pre-computed vignette overlay
       - Movie-style centred subtitles with speaker colour and text outline
       - Typewriter text effect with blinking cursor
       - Smooth crossfade between lines
       - Fade in from black
  5. Assemble into MP4 with FFmpeg
"""

import io
import json
import math
import os
import sys
import time
import subprocess
import textwrap
import tempfile
from pathlib import Path
from urllib.parse import quote

import requests
from PIL import Image, ImageDraw, ImageFont
import ollama


# ── constants ──────────────────────────────────────────────────────────────────
WIDTH, HEIGHT = 1280, 720
FPS = 24

LETTERBOX_H = 78          # black bar height top and bottom
CONTENT_TOP = LETTERBOX_H
CONTENT_BOTTOM = HEIGHT - LETTERBOX_H   # 564

KB_W, KB_H = 1440, 810    # oversized background for Ken Burns pan

TITLE_SEC = 3
MIN_LINE_SEC = 1.5
FADE_FRAMES = 16          # crossfade between lines
FADE_IN_FRAMES = 20       # fade from black at start
TYPING_SPEED = 24         # chars/second

THUMB_W = 82              # character thumbnail width
THUMB_H = 116             # character thumbnail height
THUMB_MARGIN = 14         # distance from screen edge

CHARACTER_PALETTE = [
    (255, 210, 80),    # amber
    (100, 215, 255),   # sky blue
    (155, 240, 125),   # mint
    (255, 135, 175),   # rose
    (195, 155, 255),   # lavender
]


# ── helpers ────────────────────────────────────────────────────────────────────

def load_script(path: str) -> dict:
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def get_font(size: int) -> ImageFont.FreeTypeFont:
    for path in [
        "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/calibri.ttf",
        "C:/Windows/Fonts/segoeui.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
    ]:
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except (IOError, OSError):
                continue
    return ImageFont.load_default()


def assign_colors(characters: list) -> dict:
    return {c["name"]: CHARACTER_PALETTE[i % len(CHARACTER_PALETTE)]
            for i, c in enumerate(characters)}


def check_ffmpeg() -> bool:
    try:
        subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
        return True
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False


def blend(a: Image.Image, b: Image.Image, t: float) -> Image.Image:
    return Image.blend(a.convert("RGBA"), b.convert("RGBA"), t).convert("RGB")


# ── vignette (computed once) ───────────────────────────────────────────────────

def make_vignette(strength: int = 110) -> Image.Image:
    """Dark gradient from all four edges toward the centre."""
    vig = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    draw = ImageDraw.Draw(vig)
    edge_v, edge_h_px = 220, 160
    for y in range(edge_v):
        a = int(strength * ((1 - y / edge_v) ** 2))
        draw.line([(0, y), (WIDTH, y)], fill=(0, 0, 0, a))
        draw.line([(0, HEIGHT - 1 - y), (WIDTH, HEIGHT - 1 - y)], fill=(0, 0, 0, a))
    for x in range(edge_h_px):
        a = int(strength * 0.55 * ((1 - x / edge_h_px) ** 2))
        draw.line([(x, 0), (x, HEIGHT)], fill=(0, 0, 0, a))
        draw.line([(WIDTH - 1 - x, 0), (WIDTH - 1 - x, HEIGHT)], fill=(0, 0, 0, a))
    return vig


VIGNETTE = make_vignette()

LETTERBOX_TOP = Image.new("RGB", (WIDTH, LETTERBOX_H), (0, 0, 0))
LETTERBOX_BOT = Image.new("RGB", (WIDTH, LETTERBOX_H), (0, 0, 0))


def apply_cinematic(frame: Image.Image) -> Image.Image:
    """Apply vignette and letterbox bars to a frame."""
    frame = Image.alpha_composite(frame.convert("RGBA"), VIGNETTE).convert("RGB")
    frame.paste(LETTERBOX_TOP, (0, 0))
    frame.paste(LETTERBOX_BOT, (0, CONTENT_BOTTOM))
    return frame


# ── Ollama prompt generation ───────────────────────────────────────────────────

def _ask_ollama(prompt_text: str, fallback: str, log=print) -> str:
    try:
        resp = ollama.chat(model="llama3",
                           messages=[{"role": "user", "content": prompt_text}])
        return resp["message"]["content"].strip().strip('"').strip("'")
    except Exception as e:
        log(f"  Ollama unavailable ({e}), using fallback.")
        return fallback


def generate_portrait_prompt(character: dict, theme: str, log=print) -> str:
    name = character.get("name", "character")
    role = character.get("role", "person")
    personality = character.get("personality", "")
    return _ask_ollama(
        f"Write a SHORT image prompt (10-15 words) for a character portrait. "
        f"Full body, facing forward, plain dark background. No text.\n"
        f"Name: {name}  Role: {role}  Personality: {personality}  Mood: {theme}\n"
        f"Output ONLY the prompt. No quotes.",
        fallback=f"{role}, full body portrait, plain dark background, cinematic",
        log=log,
    )


def generate_line_prompt(script: dict, line: dict, log=print) -> str:
    """Concise cinematic environment prompt for one dialogue line."""
    theme = script.get("theme", "dramatic")
    summary = script.get("scene_summary", "")
    speaker = line.get("speaker", "")
    text = line.get("text", "")
    return _ask_ollama(
        f"Write a SHORT cinematic image prompt (max 15 words) for a movie background. "
        f"Environment and mood only — no people, no text.\n"
        f"Scene: {summary}\nMood: {theme}\n"
        f"What is happening now: {speaker} says \"{text[:80]}\"\n"
        f"Use cinematography terms: golden hour, shallow depth of field, anamorphic, etc.\n"
        f"Output ONLY the prompt. No quotes. No explanation.",
        fallback=f"{theme} cinematic environment, dramatic lighting, shallow depth of field, 8K",
        log=log,
    )


# ── image fetching with retry ──────────────────────────────────────────────────

def fetch_image(prompt: str, w: int, h: int) -> Image.Image:
    url = (f"https://image.pollinations.ai/prompt/{quote(prompt)}"
           f"?width={w}&height={h}&nologo=true&model=flux")
    resp = requests.get(url, timeout=120)
    resp.raise_for_status()
    return Image.open(io.BytesIO(resp.content)).convert("RGB")


def fetch_with_retry(prompt: str, w: int, h: int,
                     max_retries: int = 4, log=print) -> Image.Image:
    for attempt in range(max_retries):
        try:
            return fetch_image(prompt, w, h)
        except requests.HTTPError as e:
            if e.response.status_code == 429 and attempt < max_retries - 1:
                wait = (attempt + 1) * 6
                log(f"  Rate limited — waiting {wait}s before retry {attempt + 2}/{max_retries}...")
                time.sleep(wait)
            else:
                raise
        except Exception:
            if attempt < max_retries - 1:
                time.sleep(4)
            else:
                raise
    raise RuntimeError("Max retries exceeded")


# ── Ken Burns ──────────────────────────────────────────────────────────────────

_KB_PATHS = [
    lambda t: (int((KB_W - WIDTH) * t * 0.55), int((KB_H - HEIGHT) * 0.2)),
    lambda t: (int((KB_W - WIDTH) * (1 - t * 0.55)), int((KB_H - HEIGHT) * 0.75)),
    lambda t: (int((KB_W - WIDTH) * 0.25), int((KB_H - HEIGHT) * t * 0.65)),
    lambda t: (int((KB_W - WIDTH) * (1 - t * 0.4)), int((KB_H - HEIGHT) * (1 - t * 0.5))),
]


def ken_burns(bg: Image.Image, t: float, direction: int) -> Image.Image:
    x, y = _KB_PATHS[direction % 4](max(0.0, min(1.0, t)))
    x = max(0, min(x, KB_W - WIDTH))
    y = max(0, min(y, KB_H - HEIGHT))
    return bg.crop((x, y, x + WIDTH, y + HEIGHT))


# ── character thumbnails ───────────────────────────────────────────────────────

def _rounded_mask(w: int, h: int, r: int = 10) -> Image.Image:
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle([(0, 0), (w - 1, h - 1)], radius=r, fill=255)
    return mask


def draw_character_thumbs(frame: Image.Image, portraits: dict,
                           char_names: list, active_speaker: str,
                           char_colors: dict) -> Image.Image:
    """
    Draw small character thumbnails anchored to the screen edges.
    Left side: even-indexed characters. Right side: odd-indexed.
    Active speaker is slightly larger and has a coloured border.
    """
    if not portraits:
        return frame

    left_chars = [n for i, n in enumerate(char_names) if i % 2 == 0]
    right_chars = [n for i, n in enumerate(char_names) if i % 2 == 1]

    # bottom of thumbnails sits just above the subtitle area
    thumb_bottom = CONTENT_BOTTOM - 95
    frame = frame.convert("RGBA")

    for side_chars, is_left in [(left_chars, True), (right_chars, False)]:
        for j, name in enumerate(side_chars):
            if name not in portraits:
                continue
            is_active = (name == active_speaker)
            scale = 1.12 if is_active else 1.0
            w = int(THUMB_W * scale)
            h = int(THUMB_H * scale)

            y = thumb_bottom - h - j * (THUMB_H + 6)
            x = THUMB_MARGIN if is_left else WIDTH - THUMB_MARGIN - w

            thumb = portraits[name].resize((w, h), Image.LANCZOS).convert("RGBA")
            thumb.putalpha(_rounded_mask(w, h, 10))

            # dim inactive characters
            if not is_active:
                r_, g_, b_, a_ = thumb.split()
                a_ = a_.point(lambda v: int(v * 0.38))
                thumb = Image.merge("RGBA", (r_, g_, b_, a_))
            else:
                # thin coloured border for active speaker
                color = char_colors.get(name, (255, 255, 255))
                bd = Image.new("RGBA", (w, h), (0, 0, 0, 0))
                ImageDraw.Draw(bd).rounded_rectangle(
                    [(1, 1), (w - 2, h - 2)], radius=10,
                    outline=(*color, 230), width=3,
                )
                thumb = Image.alpha_composite(thumb, bd)

            frame.paste(thumb, (x, y), thumb)

    return frame.convert("RGB")


# ── subtitle rendering ─────────────────────────────────────────────────────────

def draw_subtitles(frame: Image.Image, speaker: str, text: str,
                   chars_shown: int, color: tuple, global_frame: int) -> Image.Image:
    """Render movie-style centred subtitles with outline, no background box."""
    draw = ImageDraw.Draw(frame)
    visible = text[:chars_shown]
    if not visible:
        return frame

    f_name = get_font(20)
    f_text = get_font(33)
    cx = WIDTH // 2
    line_h = 40

    wrapped_lines = textwrap.wrap(visible, width=62)
    n_lines = max(len(wrapped_lines), 1)
    block_h = n_lines * line_h
    text_bottom = CONTENT_BOTTOM - 18
    text_top = text_bottom - block_h

    # speaker name — small, coloured, centred
    draw.text((cx, text_top - 26), speaker, font=f_name,
              fill=(*color, 220), anchor="mm")

    # subtitle lines with outline
    for i, line in enumerate(wrapped_lines):
        y = text_top + i * line_h
        # shadow / outline passes
        for dx, dy in [(-2, 0), (2, 0), (0, -2), (0, 2),
                       (-2, -2), (2, -2), (-2, 2), (2, 2)]:
            draw.text((cx + dx, y + dy), line, font=f_text,
                      fill=(0, 0, 0, 210), anchor="mm")
        draw.text((cx, y), line, font=f_text, fill=(255, 255, 255), anchor="mm")

    # blinking cursor while typing
    if chars_shown < len(text) and (global_frame // 7) % 2 == 0:
        last = wrapped_lines[-1] if wrapped_lines else ""
        cx_cur = cx + int(f_text.getlength(last) / 2) + 6
        cy_cur = text_top + (len(wrapped_lines) - 1) * line_h
        draw.text((cx_cur, cy_cur), "|", font=f_text,
                  fill=(*color, 200), anchor="mm")

    return frame


# ── title card ─────────────────────────────────────────────────────────────────

def render_title_card(bg_crop: Image.Image, title: str,
                      theme: str, summary: str) -> Image.Image:
    frame = Image.alpha_composite(
        bg_crop.convert("RGBA"),
        Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 160)),
    ).convert("RGB")
    draw = ImageDraw.Draw(frame)
    cx, cy = WIDTH // 2, HEIGHT // 2

    draw.text((cx, cy - 85), title, font=get_font(62),
              fill=(255, 225, 75), anchor="mm")
    draw.text((cx, cy - 28), f"[ {theme.upper()} ]", font=get_font(22),
              fill=(170, 170, 170), anchor="mm")
    draw.multiline_text((cx, cy + 28), textwrap.fill(summary, width=62),
                        font=get_font(27), fill=(215, 215, 215),
                        anchor="mm", align="center")

    return apply_cinematic(frame)


# ── main composite ─────────────────────────────────────────────────────────────

def composite_frame(bg_crop: Image.Image, speaker: str, text: str,
                    chars_shown: int, global_frame: int, color: tuple,
                    portraits: dict = None, char_names: list = None,
                    char_colors: dict = None) -> Image.Image:
    frame = bg_crop.copy()
    frame = apply_cinematic(frame)
    if portraits and char_names:
        frame = draw_character_thumbs(frame, portraits, char_names,
                                      speaker, char_colors or {})
    frame = draw_subtitles(frame, speaker, text, chars_shown, color, global_frame)
    return frame


# ── video assembly ─────────────────────────────────────────────────────────────

def assemble_video(frames_dir: Path, output_path: Path, fps: int = FPS, log=print):
    log("  Running FFmpeg...")
    cmd = [
        "ffmpeg", "-y",
        "-framerate", str(fps),
        "-i", str(frames_dir / "frame_%05d.png"),
        "-c:v", "libx264", "-preset", "fast", "-crf", "20",
        "-pix_fmt", "yuv420p",
        str(output_path),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"FFmpeg error:\n{result.stderr[-800:]}")


# ── main render ────────────────────────────────────────────────────────────────

def render_scene(json_path: str, output_dir: str = "output", log=print) -> str:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    log("Loading script...")
    script = load_script(json_path)
    title = script.get("title", "scene")
    theme = script.get("theme", "")
    summary = script.get("scene_summary", "")
    characters = script.get("characters", [])
    dialogue = script.get("dialogue_with_timing", script.get("dialogue", []))
    char_colors = assign_colors(characters)
    safe = "".join(c if c.isalnum() or c in " _-" else "_" for c in title).replace(" ", "_")
    char_names = [c["name"] for c in characters]

    # ── phase 1: generate prompts ──────────────────────────────────────────────
    total_imgs = len(dialogue) + len(characters)
    log(f"\n[1/3] Generating prompts ({len(dialogue)} scene + {len(characters)} portrait)...")
    line_prompts = []
    for i, line in enumerate(dialogue):
        speaker = line.get("speaker", "")
        log(f"  Scene prompt {i + 1}/{len(dialogue)}: {speaker}...")
        line_prompts.append(generate_line_prompt(script, line, log))
    portrait_prompts = {}
    for char in characters:
        name = char["name"]
        log(f"  Portrait prompt: {name}...")
        portrait_prompts[name] = generate_portrait_prompt(char, theme, log)

    # ── phase 2: download all images sequentially (avoids 429) ────────────────
    log(f"\n[2/3] Downloading {total_imgs} images (sequential, with auto-retry)...")
    scene_bgs: list[Image.Image] = []
    for i, prompt in enumerate(line_prompts):
        log(f"  Scene {i + 1}/{len(dialogue)}: {prompt[:70]}...")
        try:
            img = fetch_with_retry(prompt, WIDTH, HEIGHT, log=log)
            scene_bgs.append(img.resize((KB_W, KB_H), Image.LANCZOS))
            log(f"  Scene {i + 1} done.")
        except Exception as e:
            log(f"  Scene {i + 1} FAILED ({e}), using fallback.")
            scene_bgs.append(Image.new("RGB", (KB_W, KB_H), (20, 15, 30)))
        time.sleep(2)

    portraits: dict[str, Image.Image] = {}
    for char in characters:
        name = char["name"]
        log(f"  Portrait: {name}...")
        try:
            img = fetch_with_retry(portrait_prompts[name],
                                   THUMB_W * 3, THUMB_H * 3, log=log)
            portraits[name] = img.resize((THUMB_W, THUMB_H), Image.LANCZOS).convert("RGBA")
            log(f"  Portrait {name} done.")
        except Exception as e:
            log(f"  Portrait {name} FAILED ({e}), using placeholder.")
            portraits[name] = Image.new("RGBA", (THUMB_W, THUMB_H), (60, 45, 80, 255))
        if char != characters[-1]:
            time.sleep(2)

    # ── phase 3: render frames ─────────────────────────────────────────────────
    log("\n[3/3] Rendering animated frames...")
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        idx = 0

        def save(frame: Image.Image):
            nonlocal idx
            frame.convert("RGB").save(tmpdir / f"frame_{idx:05d}.png")
            idx += 1

        # title card with fade from black
        title_crop = ken_burns(scene_bgs[0], 0.0, 0)
        title_frame = render_title_card(title_crop, title, theme, summary)
        black = Image.new("RGB", (WIDTH, HEIGHT), (0, 0, 0))
        for f in range(FADE_IN_FRAMES):
            save(blend(black, title_frame, (f + 1) / FADE_IN_FRAMES))
        hold = TITLE_SEC * FPS - FADE_IN_FRAMES
        for f in range(hold):
            t = f / max(hold - 1, 1) * 0.3
            save(render_title_card(ken_burns(scene_bgs[0], t, 0), title, theme, summary))
        log(f"  Title card: {TITLE_SEC}s")

        prev_frame = title_frame

        # dialogue lines
        for li, line in enumerate(dialogue):
            speaker = line.get("speaker", "Narrator")
            text = line.get("text", "")
            dur = max(line.get("estimated_duration_sec", 3.0), MIN_LINE_SEC)
            total_f = int(dur * FPS)
            type_f = int(len(text) * FPS / TYPING_SPEED)
            hold_f = max(0, total_f - FADE_FRAMES - type_f)
            color = char_colors.get(speaker, (255, 255, 255))
            direction = li % 4
            bg = scene_bgs[li]

            # crossfade to first frame of new line
            for f in range(FADE_FRAMES):
                t = (f + 1) / FADE_FRAMES
                crop = ken_burns(bg, t * 0.04, direction)
                curr = composite_frame(crop, speaker, text, 0, idx, color,
                                       portraits, char_names, char_colors)
                save(blend(prev_frame, curr, t))

            # typewriter phase
            for f in range(type_f):
                t_kb = (FADE_FRAMES + f) / max(total_f - 1, 1)
                crop = ken_burns(bg, t_kb, direction)
                chars = min(len(text), int((f + 1) * TYPING_SPEED / FPS))
                frame = composite_frame(crop, speaker, text, chars, idx, color,
                                        portraits, char_names, char_colors)
                save(frame)

            # hold phase (full text, animation continues)
            for f in range(hold_f):
                t_kb = (FADE_FRAMES + type_f + f) / max(total_f - 1, 1)
                crop = ken_burns(bg, t_kb, direction)
                frame = composite_frame(crop, speaker, text, len(text), idx, color,
                                        portraits, char_names, char_colors)
                save(frame)
                prev_frame = frame

            log(f"  Line {li + 1:2d}/{len(dialogue)}: {speaker:<14} {dur:.1f}s")

        log(f"  Total frames: {idx}  (~{idx / FPS:.1f}s)")

        output_video = out / f"{safe}.mp4"
        assemble_video(tmpdir, output_video, log=log)

    log(f"\nDone! Video saved to:\n  {output_video.resolve()}")
    return str(output_video.resolve())


# ── CLI ────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if not check_ffmpeg():
        print("ERROR: FFmpeg not found.")
        sys.exit(1)
    if len(sys.argv) < 2:
        print("Usage: python scene_renderer.py <script.json> [output_dir]")
        sys.exit(0)
    render_scene(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "output")
