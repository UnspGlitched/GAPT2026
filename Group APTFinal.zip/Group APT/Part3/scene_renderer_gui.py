#!/usr/bin/env python3
"""
Part 3 - Visual Rendering & Assembly (GUI)
Tkinter front-end for scene_renderer.py
"""

import threading
import tkinter as tk
from tkinter import filedialog, ttk, scrolledtext, messagebox
from pathlib import Path

from scene_renderer import render_scene, check_ffmpeg


class SceneRendererApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Scene Renderer – Part 3: Visual Rendering & Assembly")
        self.geometry("720x560")
        self.resizable(False, False)
        self.configure(bg="#1e1e2e")
        self._build_ui()

    # ── UI construction ────────────────────────────────────────────────────────

    def _build_ui(self):
        BG = "#1e1e2e"
        FG = "#cdd6f4"
        ENTRY_BG = "#313244"
        BTN_BG = "#89b4fa"
        BTN_FG = "#1e1e2e"

        def label(parent, text):
            return tk.Label(parent, text=text, bg=BG, fg=FG,
                            font=("Segoe UI", 10), anchor="w")

        def entry_row(parent, var):
            frame = tk.Frame(parent, bg=BG)
            frame.pack(fill="x", padx=14, pady=(0, 10))
            e = tk.Entry(frame, textvariable=var, width=62,
                         bg=ENTRY_BG, fg=FG, insertbackground=FG,
                         relief="flat", font=("Segoe UI", 10))
            e.pack(side="left", ipady=4, padx=(0, 8))
            return frame

        # header
        tk.Label(self, text="Script-to-Scene Renderer", bg=BG, fg="#cba6f7",
                 font=("Segoe UI", 16, "bold")).pack(pady=(18, 4))
        tk.Label(self, text="Converts a Part 1 script JSON into a rendered video scene",
                 bg=BG, fg="#a6adc8", font=("Segoe UI", 9)).pack(pady=(0, 16))

        ttk.Separator(self).pack(fill="x", padx=14, pady=(0, 12))

        # JSON input
        label(self, "Script JSON (output from Part 1):").pack(fill="x", padx=14)
        self.json_var = tk.StringVar()
        row1 = entry_row(self, self.json_var)
        tk.Button(row1, text="Browse…", command=self._browse_json,
                  bg=ENTRY_BG, fg=FG, relief="flat", font=("Segoe UI", 9),
                  cursor="hand2").pack(side="left")

        # output folder
        label(self, "Output folder:").pack(fill="x", padx=14)
        self.out_var = tk.StringVar(value="output")
        row2 = entry_row(self, self.out_var)
        tk.Button(row2, text="Browse…", command=self._browse_out,
                  bg=ENTRY_BG, fg=FG, relief="flat", font=("Segoe UI", 9),
                  cursor="hand2").pack(side="left")

        # render button
        self.btn = tk.Button(
            self, text="▶  Render Scene", command=self._start_render,
            bg=BTN_BG, fg=BTN_FG, font=("Segoe UI", 12, "bold"),
            relief="flat", padx=14, pady=8, cursor="hand2",
            activebackground="#74c7ec", activeforeground=BTN_FG,
        )
        self.btn.pack(pady=14)

        # progress bar
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Blue.Horizontal.TProgressbar",
                        troughcolor=ENTRY_BG, background=BTN_BG)
        self.progress = ttk.Progressbar(self, mode="indeterminate", length=680,
                                         style="Blue.Horizontal.TProgressbar")
        self.progress.pack(padx=14)

        # log
        label(self, "Log:").pack(fill="x", padx=14, pady=(12, 2))
        self.log_box = scrolledtext.ScrolledText(
            self, height=13, state="disabled",
            font=("Cascadia Code", 9), bg="#11111b", fg="#cdd6f4",
            insertbackground=FG, relief="flat",
        )
        self.log_box.pack(fill="both", expand=True, padx=14, pady=(0, 14))

    # ── event handlers ─────────────────────────────────────────────────────────

    def _browse_json(self):
        path = filedialog.askopenfilename(
            title="Select script JSON",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if path:
            self.json_var.set(path)

    def _browse_out(self):
        path = filedialog.askdirectory(title="Select output folder")
        if path:
            self.out_var.set(path)

    def _log(self, msg: str):
        self.log_box.configure(state="normal")
        self.log_box.insert("end", msg + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")
        self.update_idletasks()

    def _start_render(self):
        json_path = self.json_var.get().strip()
        out_dir = self.out_var.get().strip() or "output"

        if not json_path:
            messagebox.showerror("Missing input", "Please select a script JSON file.")
            return

        if not check_ffmpeg():
            messagebox.showerror(
                "FFmpeg not found",
                "FFmpeg is required but was not found on PATH.\n"
                "Download it from: https://ffmpeg.org/download.html",
            )
            return

        self.btn.configure(state="disabled")
        self.progress.start(10)
        self.log_box.configure(state="normal")
        self.log_box.delete("1.0", "end")
        self.log_box.configure(state="disabled")

        def run():
            try:
                render_scene(json_path, out_dir, log=self._log)
                self.after(0, lambda: messagebox.showinfo(
                    "Done", f"Video saved to:\n{Path(out_dir).resolve()}"))
            except Exception as exc:
                self._log(f"\nERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror("Error", e))
            finally:
                self.after(0, self._render_done)

        threading.Thread(target=run, daemon=True).start()

    def _render_done(self):
        self.btn.configure(state="normal")
        self.progress.stop()


if __name__ == "__main__":
    app = SceneRendererApp()
    app.mainloop()
